﻿using HutongGames.PlayMaker;
using UnityEngine;
using System.Collections;

[ActionCategory("Datablocks")]
[HutongGames.PlayMaker.Tooltip("Gets a datablock based on name.")]
public class GetDatablock : FsmStateAction
{
    [RequiredField]
    public FsmString datablockName;

    public FsmBool caseSensitive;

    [RequiredField]
    public FsmObject storeResult;

    public override void Reset()
    {
        datablockName = null;
        storeResult = null;
        caseSensitive = false;
    }

    public override void OnEnter()
    {
        DoGetDatablock();
        Finish();
    }

    void DoGetDatablock()
    {
        if(!DatablockManager.Instance)
            return;

        storeResult.Value = DatablockManager.Instance.GetDatablock(datablockName.Value, caseSensitive.Value);
    }
}
