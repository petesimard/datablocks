﻿using HutongGames.PlayMaker;
using UnityEngine;

[ActionCategory("Datablocks")]
[HutongGames.PlayMaker.Tooltip("Tests if datablock is a child of a parent.")]
public class DatablockIsChildOf : FsmStateAction
{
    [RequiredField] [HutongGames.PlayMaker.Tooltip("The Datablock to test.")] public FsmObject datablock;
    [HutongGames.PlayMaker.Tooltip("Repeat every frame.")] public bool everyFrame;

    [HutongGames.PlayMaker.Tooltip("Event to send if the GameObject does not have children.")] public FsmEvent falseEvent;
    [RequiredField] [HutongGames.PlayMaker.Tooltip("The parent to check for.")] public FsmObject parent;

    [UIHint(UIHint.Variable)] [HutongGames.PlayMaker.Tooltip("Store the result in a bool variable.")] public FsmBool storeResult;
    [HutongGames.PlayMaker.Tooltip("Event to send if the GameObject has children.")] public FsmEvent trueEvent;

    public override void Reset()
    {
        datablock = null;
        parent = null;
        trueEvent = null;
        falseEvent = null;
        storeResult = null;
        everyFrame = false;
    }

    public override void OnEnter()
    {
        DoHasChildren();

        if (!everyFrame)
        {
            Finish();
        }
    }

    public override void OnUpdate()
    {
        DoHasChildren();
    }

    private void DoHasChildren()
    {
        if (datablock == null || parent == null || datablock.Value == null || parent.Value == null || DatablockManager.Instance == null)
        {
            return;
        }

        var db = datablock.Value as Datablock;
        var dbParent = parent.Value as Datablock;

        if (db == null || dbParent == null)
        {
            return;
        }

        bool hasChildren = db.IsChildOf(dbParent);

        storeResult.Value = hasChildren;

        Fsm.Event(hasChildren ? trueEvent : falseEvent);
    }
}