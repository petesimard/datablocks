﻿using HutongGames.PlayMaker;

[ActionCategory("Datablocks")]
[Tooltip("Tests if datablock is a parent of a child.")]
public class DatablockIsParentOf : FsmStateAction
{
    [RequiredField] [Tooltip("The child to check for.")] public FsmObject child;
    [RequiredField] [Tooltip("The Datablock to test.")] public FsmObject datablock;
    [Tooltip("Repeat every frame.")] public bool everyFrame;


    [Tooltip("Event to send if the GameObject does not have children.")] public FsmEvent falseEvent;

    [UIHint(UIHint.Variable)] [Tooltip("Store the result in a bool variable.")] public FsmBool storeResult;
    [Tooltip("Event to send if the GameObject has children.")] public FsmEvent trueEvent;

    public override void Reset()
    {
        datablock = null;
        child = null;
        trueEvent = null;
        falseEvent = null;
        storeResult = null;
        everyFrame = false;
    }

    public override void OnEnter()
    {
        DoHasChildren();

        if (!everyFrame)
        {
            Finish();
        }
    }

    public override void OnUpdate()
    {
        DoHasChildren();
    }

    private void DoHasChildren()
    {
        if (datablock == null || child == null || datablock.Value == null || child.Value == null || DatablockManager.Instance == null)
        {
            return;
        }

        var db = datablock.Value as Datablock;
        var dbChild = child.Value as Datablock;

        if (db == null || dbChild == null)
        {
            return;
        }


        bool hasChildren = dbChild.IsChildOf(db);

        storeResult.Value = hasChildren;

        Fsm.Event(hasChildren ? trueEvent : falseEvent);
    }
}